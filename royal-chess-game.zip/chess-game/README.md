# Royal Chess

A browser-based chess game made with HTML, CSS, and JavaScript.

## Features
- Full legal move validation through chess.js
- Check, checkmate, stalemate, castling, en passant, and promotion
- Stockfish 18 browser engine with a local fallback AI
- Two-player local mode
- Difficulty selector
- Move history and PGN copy
- Chess clocks, undo, restart, and board flip
- Responsive desktop/mobile layout

## Run
Because browser workers are more reliable over HTTP, serve the folder locally rather than double-clicking the file.

### Windows
1. Open the folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `index.html` and select **Open with Live Server**.

Or, with Python installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

The game requires an internet connection for chess.js and the Stockfish engine CDN. If Stockfish cannot load, the game clearly switches to a simpler local AI fallback.
