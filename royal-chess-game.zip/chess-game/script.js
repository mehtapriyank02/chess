/* Royal Chess — frontend chess game with chess.js rules and Stockfish 18 ASM worker. */
const game = new Chess();
const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
const movesEl = document.getElementById('moves');
const modeEl = document.getElementById('mode');
const difficultyEl = document.getElementById('difficulty');
const engineStatusEl = document.getElementById('engineStatus');
const promotionDialog = document.getElementById('promotionDialog');
const pieces = {w:{k:'♔',q:'♕',r:'♖',b:'♗',n:'♘',p:'♙'},b:{k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'}};
let selected = null, legalMoves = [], flipped = false, lastMove = null, pendingPromotion = null;
let engine = null, engineReady = false, engineThinking = false;
let whiteSeconds = 600, blackSeconds = 600, timer = null;

function createEngine(){
  engineStatusEl.textContent = 'Loading Stockfish…';
  try {
    const engineUrl = 'https://cdn.jsdelivr.net/npm/stockfish@18.0.8/bin/stockfish-18-asm.js';
    const workerCode = `importScripts('${engineUrl}');`;
    engine = new Worker(URL.createObjectURL(new Blob([workerCode], {type:'text/javascript'})));
    engine.onmessage = e => handleEngineLine(String(e.data));
    engine.onerror = () => engineFailed();
    engine.postMessage('uci');
  } catch (err) { engineFailed(); }
}
function engineFailed(){
  engineReady=false; engine=null;
  engineStatusEl.textContent='Stockfish unavailable — local AI fallback';
}
function handleEngineLine(line){
  if(line==='uciok'){ engine.postMessage('isready'); }
  if(line==='readyok'){ engineReady=true; engineStatusEl.textContent='Stockfish 18 ready'; }
  if(line.startsWith('bestmove')){
    engineThinking=false; engineStatusEl.classList.remove('thinking');
    const uci=line.split(' ')[1];
    if(!uci || uci==='(none)') return;
    const move=game.move({from:uci.slice(0,2),to:uci.slice(2,4),promotion:uci[4]||'q'});
    if(move){lastMove={from:move.from,to:move.to}; afterMove();}
  }
}

function squareOrder(){
  const files = flipped ? ['h','g','f','e','d','c','b','a'] : ['a','b','c','d','e','f','g','h'];
  const ranks = flipped ? [1,2,3,4,5,6,7,8] : [8,7,6,5,4,3,2,1];
  return ranks.flatMap(r=>files.map(f=>f+r));
}
function render(){
  boardEl.innerHTML='';
  const order=squareOrder();
  order.forEach((sq,index)=>{
    const file=sq.charCodeAt(0)-97, rank=Number(sq[1]);
    const cell=document.createElement('div');
    cell.className=`square ${(file+rank)%2?'light':'dark'}`;
    if(selected===sq) cell.classList.add('selected');
    if(lastMove && (lastMove.from===sq||lastMove.to===sq)) cell.classList.add('last');
    const legal=legalMoves.find(m=>m.to===sq);
    if(legal) cell.classList.add(game.get(sq)?'capture':'legal');
    const p=game.get(sq);
    if(p){const span=document.createElement('span');span.className=`piece ${p.color==='w'?'white-piece':'black-piece'}`;span.textContent=pieces[p.color][p.type];cell.appendChild(span);}
    const isLeft=index%8===0, isBottom=index>=56;
    if(isLeft){const c=document.createElement('span');c.className='coordinate rank';c.textContent=sq[1];cell.appendChild(c);}
    if(isBottom){const c=document.createElement('span');c.className='coordinate file';c.textContent=sq[0];cell.appendChild(c);}
    cell.onclick=()=>onSquareClick(sq);
    boardEl.appendChild(cell);
  });
  updateStatus(); updateMoves(); updateClocks();
}
function onSquareClick(sq){
  if(game.game_over() || engineThinking) return;
  if(modeEl.value==='ai' && game.turn()==='b') return;
  const piece=game.get(sq);
  if(selected){
    const candidate=legalMoves.find(m=>m.to===sq);
    if(candidate){
      if(candidate.flags.includes('p')){ pendingPromotion={from:selected,to:sq}; promotionDialog.showModal(); return; }
      makePlayerMove(selected,sq,'q'); return;
    }
  }
  if(piece && piece.color===game.turn()){
    selected=sq; legalMoves=game.moves({square:sq,verbose:true});
  } else {selected=null;legalMoves=[];}
  render();
}
function makePlayerMove(from,to,promotion){
  const move=game.move({from,to,promotion});
  if(!move) return;
  lastMove={from:move.from,to:move.to}; selected=null;legalMoves=[];afterMove();
}
promotionDialog.querySelectorAll('button').forEach(btn=>btn.onclick=()=>{
  promotionDialog.close();
  if(pendingPromotion){makePlayerMove(pendingPromotion.from,pendingPromotion.to,btn.dataset.piece);pendingPromotion=null;}
});
function afterMove(){
  render();
  if(modeEl.value==='ai' && game.turn()==='b' && !game.game_over()) setTimeout(requestAiMove,250);
}
function requestAiMove(){
  if(game.game_over()) return;
  engineThinking=true; engineStatusEl.classList.add('thinking'); engineStatusEl.textContent=engineReady?'Stockfish is thinking…':'Local AI is thinking…';
  if(engineReady && engine){
    engine.postMessage('position fen '+game.fen());
    engine.postMessage('go depth '+difficultyEl.value);
  } else setTimeout(fallbackAiMove,350);
}
function fallbackAiMove(){
  const moves=game.moves({verbose:true});
  if(!moves.length) return;
  const values={p:100,n:320,b:330,r:500,q:900,k:20000};
  let bestScore=-Infinity,best=[];
  for(const m of moves){
    let score=(m.captured?values[m.captured]:0)+(m.promotion?values[m.promotion]:0)+Math.random()*35;
    game.move(m); if(game.in_checkmate()) score+=100000; else if(game.in_check()) score+=60; game.undo();
    if(score>bestScore){bestScore=score;best=[m];}else if(Math.abs(score-bestScore)<1)best.push(m);
  }
  const choice=best[Math.floor(Math.random()*best.length)];
  const move=game.move(choice);engineThinking=false;engineStatusEl.classList.remove('thinking');engineStatusEl.textContent='Local AI fallback';
  lastMove={from:move.from,to:move.to};afterMove();
}
function updateStatus(){
  let text=game.turn()==='w'?'White to move':'Black to move';
  if(game.in_checkmate()) text=`Checkmate — ${game.turn()==='w'?'Black':'White'} wins`;
  else if(game.in_stalemate()) text='Draw by stalemate';
  else if(game.in_threefold_repetition()) text='Draw by repetition';
  else if(game.insufficient_material()) text='Draw — insufficient material';
  else if(game.in_draw()) text='Draw';
  else if(game.in_check()) text=`${game.turn()==='w'?'White':'Black'} is in check`;
  statusEl.textContent=text;
  document.getElementById('whiteClock').classList.toggle('active',game.turn()==='w'&&!game.game_over());
  document.getElementById('blackClock').classList.toggle('active',game.turn()==='b'&&!game.game_over());
}
function updateMoves(){
  const history=game.history();
  if(!history.length){movesEl.innerHTML='<p class="empty">No moves yet</p>';return;}
  movesEl.innerHTML='';
  for(let i=0;i<history.length;i+=2){
    movesEl.insertAdjacentHTML('beforeend',`<span class="move-number">${i/2+1}.</span><span>${history[i]||''}</span><span>${history[i+1]||''}</span>`);
  }
  movesEl.scrollTop=movesEl.scrollHeight;
}
function formatTime(s){return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
function updateClocks(){document.getElementById('whiteClock').textContent=formatTime(whiteSeconds);document.getElementById('blackClock').textContent=formatTime(blackSeconds);}
function startTimer(){clearInterval(timer);timer=setInterval(()=>{if(game.game_over())return;if(game.turn()==='w')whiteSeconds--;else blackSeconds--;if(whiteSeconds<=0||blackSeconds<=0){clearInterval(timer);statusEl.textContent=`Time out — ${whiteSeconds<=0?'Black':'White'} wins`;}updateClocks();},1000);}
function newGame(){if(engineThinking&&engine)engine.postMessage('stop');game.reset();selected=null;legalMoves=[];lastMove=null;engineThinking=false;whiteSeconds=blackSeconds=600;document.getElementById('blackName').textContent=modeEl.value==='ai'?'Stockfish':'Player 2';render();startTimer();}
document.getElementById('newBtn').onclick=newGame;
document.getElementById('undoBtn').onclick=()=>{if(engineThinking&&engine)engine.postMessage('stop');engineThinking=false;game.undo();if(modeEl.value==='ai')game.undo();lastMove=null;selected=null;legalMoves=[];render();};
document.getElementById('flipBtn').onclick=()=>{flipped=!flipped;render();};
modeEl.onchange=newGame;
document.getElementById('copyPgnBtn').onclick=async()=>{try{await navigator.clipboard.writeText(game.pgn());const b=document.getElementById('copyPgnBtn');b.textContent='Copied!';setTimeout(()=>b.textContent='Copy PGN',1200);}catch{alert(game.pgn()||'No moves yet');}};
createEngine();render();startTimer();
